<?php
    include "view/dashboard.php";
?>